package common.utils.jgrapht.pojo;

public abstract class PojoPayloadAbstract {

	String clazz; //Identification of the PayLoad Class
	String id;
	
	public PojoPayloadAbstract() {
		this.setClazz(this.getClass().getName());
	}

	public String getClazz() {
		return clazz;
	}

	public void setClazz(String clazz) {
		this.clazz = clazz;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	
}
