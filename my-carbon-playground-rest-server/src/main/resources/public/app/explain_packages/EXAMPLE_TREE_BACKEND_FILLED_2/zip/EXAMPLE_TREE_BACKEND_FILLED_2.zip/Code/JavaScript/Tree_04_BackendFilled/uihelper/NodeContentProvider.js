export function getNodeContent(node) {

    return(
        <>
            {node.label}
        </>
    );

}